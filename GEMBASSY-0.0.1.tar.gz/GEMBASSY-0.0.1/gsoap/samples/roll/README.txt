This directory contains a "one-liner" service: gSOAP Web service and client
applications that are only one line long (not counting the usual #includes).

The oneliners are small, but they can do a number of useful things. The
complete list of oneliners is:

samples/gmt       return current time in GMT
samples/hello     "Hello World!"
samples/roll      rolling a die

You can use the client programs right away after compilation since they connect
to our server. To run the server examples you have to install them as CGI
applications.
